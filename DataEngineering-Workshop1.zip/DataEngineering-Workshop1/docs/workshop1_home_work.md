# Workshop 1 Homework.

### Aim: Scrape the website and store blog data in a PostgreSQL database

- Write a Python program to Scrape the pages from [Python Blogs](https://blog.python.org/) and save the data into the DB.
- Dockerize the project.

